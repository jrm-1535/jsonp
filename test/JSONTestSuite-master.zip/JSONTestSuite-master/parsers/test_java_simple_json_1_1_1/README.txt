jar cvfm TestJSONParsing.jar META-INF/MANIFEST.MF json-simple-1.1.1.jar TestJSONParsing.class

java -jar TestJSONParsing.jar
