#!/bin/sh

qmake .
make
