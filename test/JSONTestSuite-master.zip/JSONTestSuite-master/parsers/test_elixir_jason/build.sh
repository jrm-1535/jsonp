#!/bin/bash
mix do deps.get, deps.compile, escript.build
