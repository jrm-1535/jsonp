[
  inputs: ["mix.exs", "{config,lib,test}/**/*.{ex,exs}"]
]
